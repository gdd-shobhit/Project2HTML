# What we wanna do
Make Classes for player and pentagon

Make the pentagon shrink
